export const environment = {
    production: false,
    apiUrl: 'http://localhost:8080/api',
    apiKey: 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJyZWR6ZWh6enoiLCJpYXQiOjE3MDg4ODE4NDIsImV4cCI6MTcwODk2ODI0Mn0.NbjL2x0TAjfG8Ihdhbo-Q_qohHDOhqrsZXhHrzXIkbU'
};