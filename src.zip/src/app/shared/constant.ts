export const constantURL = {
    apiEndpoint:'https://35.180.230.170:443',
}